My font for free use is only allowed in private, non-profit projects.
If you make money from using my font, please buy a commercial license.
https://koplexsstudio.com/product/samarata-natural-handwritten-brush-font/

or emai: koplexsstudio@gmail.com


For a company license, contact me via email
Contact me at koplexsstudio@gmail.com
And follow my Instagram for updates: http://www.instagram.com/koplexs_studio


If you want to DONATE click here http://www.paypal.me/koplexs173
I really appreciate your contribution.

keep sharing
Thank you :